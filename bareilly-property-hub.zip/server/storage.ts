import { InsertUser, User, Property, InsertProperty } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  getProperties(): Promise<Property[]>;
  getProperty(id: number): Promise<Property | undefined>;
  createProperty(property: InsertProperty): Promise<Property>;
  updateProperty(id: number, property: Partial<InsertProperty>): Promise<Property>;
  deleteProperty(id: number): Promise<void>;
  getPropertiesByUser(userId: number): Promise<Property[]>;

  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private properties: Map<number, Property>;
  private currentUserId: number;
  private currentPropertyId: number;
  sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.properties = new Map();
    this.currentUserId = 1;
    this.currentPropertyId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });

    // Add some sample properties
    this.initializeSampleData();
  }

  private async initializeSampleData() {
    // Create a sample user
    const user = await this.createUser({
      username: "demo",
      password: "password123",
      name: "Demo User",
      phone: "+91 9876543210"
    });

    // Create sample properties
    const sampleProperties = [
      {
        userId: user.id,
        title: "Modern 3BHK Apartment in Civil Lines",
        description: "Spacious 3BHK apartment with modern amenities, 24/7 security, and reserved parking. Located in the heart of Civil Lines.",
        price: "4500000",
        size: "1500",
        location: "Civil Lines, Bareilly",
        latitude: "28.3670",
        longitude: "79.4304",
        phone: "+91 9876543210",
        imageUrls: [
          "https://images.unsplash.com/photo-1580587771525-78b9dba3b914",
          "https://images.unsplash.com/photo-1600585154340-be6161a56a0c",
          "https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b",
          "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3"
        ],
        condition: "Excellent",
        amenities: ["Power Backup", "Security", "Lift", "Reserved Parking", "Swimming Pool", "Gym"],
        facilities: ["Club House", "Community Hall", "Children's Play Area", "Garden"],
        propertyType: "Apartment",
        bedrooms: 3,
        bathrooms: 2,
        furnished: true
      },
      {
        userId: user.id,
        title: "Commercial Space in Pilibhit Road",
        description: "Prime commercial property on Pilibhit Road. Perfect for retail or office space with ample parking.",
        price: "8500000",
        size: "2000",
        location: "Pilibhit Road, Bareilly",
        latitude: "28.3640",
        longitude: "79.4200",
        phone: "+91 9876543210",
        imageUrls: [
          "https://images.unsplash.com/photo-1577412647305-991150c7d163",
          "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab",
          "https://images.unsplash.com/photo-1497366811353-6870744d04b2",
          "https://images.unsplash.com/photo-1497366216548-37526070297c"
        ],
        condition: "Good",
        amenities: ["24/7 Power Backup", "Central AC", "Elevator", "Parking"],
        facilities: ["Conference Room", "Cafeteria", "Reception Area"],
        propertyType: "Commercial",
        bedrooms: null,
        bathrooms: 2,
        furnished: false
      },
      {
        userId: user.id,
        title: "Residential Plot in Rampur Garden",
        description: "Ready-to-build residential plot in the peaceful locality of Rampur Garden. All utilities available.",
        price: "2500000",
        size: "1200",
        location: "Rampur Garden, Bareilly",
        latitude: "28.3720",
        longitude: "79.4350",
        phone: "+91 9876543210",
        imageUrls: [
          "https://images.unsplash.com/photo-1500382017468-9049fed747ef",
          "https://images.unsplash.com/photo-1585773690161-7b1cd0accfcf",
          "https://images.unsplash.com/photo-1588880331179-bc9b93a8cb5e"
        ],
        condition: "Ready to Build",
        amenities: ["Water Connection", "Electricity", "Road Access"],
        facilities: ["Gated Community", "Security"],
        propertyType: "Plot",
        bedrooms: null,
        bathrooms: null,
        furnished: false
      }
    ];

    for (const property of sampleProperties) {
      await this.createProperty(property);
    }
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getProperties(): Promise<Property[]> {
    return Array.from(this.properties.values());
  }

  async getProperty(id: number): Promise<Property | undefined> {
    return this.properties.get(id);
  }

  async createProperty(insertProperty: InsertProperty): Promise<Property> {
    const id = this.currentPropertyId++;
    const property: Property = {
      ...insertProperty,
      id,
      createdAt: new Date(),
    };
    this.properties.set(id, property);
    return property;
  }

  async updateProperty(id: number, updateData: Partial<InsertProperty>): Promise<Property> {
    const existing = await this.getProperty(id);
    if (!existing) throw new Error("Property not found");

    const updated: Property = {
      ...existing,
      ...updateData,
    };
    this.properties.set(id, updated);
    return updated;
  }

  async deleteProperty(id: number): Promise<void> {
    this.properties.delete(id);
  }

  async getPropertiesByUser(userId: number): Promise<Property[]> {
    return Array.from(this.properties.values()).filter(
      (property) => property.userId === userId
    );
  }
}

export const storage = new MemStorage();